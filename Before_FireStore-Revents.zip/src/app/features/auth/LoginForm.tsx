import { Button, Form } from "semantic-ui-react";
import ModelWrapper from "../../common/models/ModelWrapper";
import { FieldValue, FieldValues, useForm } from "react-hook-form";
import { useAppDispatch } from "../../Store/store";
import { closeModel } from "../../common/models/modelSlice";
import { signIn } from "./authSlice";

export default function LoginForm() {
    const {register,handleSubmit,formState:{isSubmitting,isValid,isDirty,errors}} = useForm(
        {
            mode:"onTouched"
        }
    )

    const dispatch = useAppDispatch();

    function OnSubmit(data:FieldValues)
    {
        dispatch(signIn(data))
        dispatch(closeModel())
    }

  return (
    <ModelWrapper header={"Sign into re-vents"}>
        <Form onSubmit={handleSubmit(OnSubmit)}>
            <Form.Input defaultValue="" placeholder="Email Address"
            {...register("email",{required:true,pattern:/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/})}
            error={errors.email?.type==="required" && "Email is Required" || 
        errors.email?.type==="pattern" && "email is invalid"}
            />
            <Form.Input type="password" defaultValue="" placeholder="Password"
            {...register("password",{required:true})}
            error={errors.password && "Password is Required"}
            />
            <Button
                loading={isSubmitting}
                disabled={!isValid || !isDirty || isSubmitting}
                type="submit"
                fluid
                size="large"
                color="teal"
                content="login"
            />
        </Form>
    </ModelWrapper>
  )
}