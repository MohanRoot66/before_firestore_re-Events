import { useAppSelector } from "../../../Store/store"
import ModelWrapper from "../../../common/models/ModelWrapper"

export default function TestModel() {
    const {data} = useAppSelector(state=>state.modals)
    return (
        <ModelWrapper header={"Testing 123"}>
            <div>Test data is {data}</div>
        </ModelWrapper>
  )
}