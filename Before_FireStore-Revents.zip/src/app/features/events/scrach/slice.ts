import { createSlice } from "@reduxjs/toolkit";

type State=
{
    data:number
    name:string
}

const initialState:State = 
{
    data:4321,
    name:"Joeeeeyyy"
}

export  const testslice = createSlice(
    {
        name:"test",
        initialState,
        reducers:
        {
            increment:(state)=>
            {
                state.data+=1
            },
            decrement:(state)=>
            {
                state.data-=1
            },
            incrementByamount:(state,action)=>
            {
                state.data+=action.payload
            }
        }
    }
)

export const {increment,decrement,incrementByamount}=testslice.actions