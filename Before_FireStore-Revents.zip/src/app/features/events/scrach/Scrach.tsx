import { Button } from "semantic-ui-react"
import { useAppDispatch, useAppSelector } from "../../../Store/store"
import { decrement, increment, incrementByamount } from "./slice";
import { openModel } from "../../../common/models/modelSlice";

export default function Scrach() {
  const state = useAppSelector((state)=>state.test)
  const dispatch = useAppDispatch();
  return (
    <>
      <h1>Scratch page</h1>
      <h3>The data is {state.data}</h3>
      <Button onClick={()=>dispatch(increment())} color="green" content="Increment"></Button>
      <Button onClick={()=>dispatch(decrement())} color="red" content="Decrement"></Button>
      <Button onClick={()=>dispatch(incrementByamount(3))} color="teal" content="IncrementByAmount"></Button>
      <Button onClick={()=>dispatch(openModel({type:"TestModel",data:state.data}))} color="red" content="Open model"></Button>
    </>
  )
}