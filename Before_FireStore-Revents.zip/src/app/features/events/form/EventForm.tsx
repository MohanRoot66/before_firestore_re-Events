
import { Button, Form, Header, Segment } from "semantic-ui-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../Store/store";
import { createEvent, updateEvent } from "../eventSlice";
import { v4 as uuidv4 } from 'uuid';
import { Controller, FieldValues, useForm } from "react-hook-form";
import { categoryOptions } from "./categoryOption";
import "react-datepicker/dist/react-datepicker.css"
import DatePicker from "react-datepicker";


export default function EventForm() {

    const {register,handleSubmit,control,setValue,formState:{errors,isValid,isSubmitting}}=useForm(
      {
        mode:"onTouched"
      }
    );

    const navigate = useNavigate();
    const dispatch = useAppDispatch();

    let {id} = useParams()

    const event = useAppSelector(state=>state.events).events.find(el=>el.id===id);

 
      function OnSubmit(data:FieldValues)
      {
        console.log(data)
        id=id ?? uuidv4();
        event 
        ? dispatch(updateEvent({state:{...data,date:data.date.toString()}}))
        : dispatch(createEvent({state:{...data,date:data.date.toString()},id}))
        navigate(`/events/${id}`)
      }
    

  return (
    
    <>
    <Segment clearing>
        <Header content="Event details" sub color="teal"/>
        <Form onSubmit={handleSubmit(OnSubmit)}>
            <Form.Input 
            placeholder="Event Title" 
            defaultValue={event?.title || ""} 
            {...register("title",{required:true})}
            error={errors.title && "Title is required"}
            />
          
          <Controller
            name="category"
            control={control}
            rules={{required:"Category is Required"}}
            defaultValue={event?.category}
            render={({field})=>
              (
                <Form.Select
                  options={categoryOptions}
                  placeholder="Category"
                  clearable
                  {...field}
                  onChange={(_,d)=>setValue("category",d.value,{shouldValidate:true})}
                  error={errors.category && "category is required"}
                  />
              )}
            />

           

            <Form.Input
              placeholder="Description"
              defaultValue={event?.description || ""}
              {...register("description",{required:true})}
              error={errors.description && "description is required"}
              />

            <Form.TextArea
              placeholder="City"
              defaultValue={event?.city || ""}
              {...register("city",{required:true})}
              error={errors.city && "city is required"}
              />
            <Header sub content="Location details" color="teal"/>
            <Form.Input
              placeholder="Venue"
              defaultValue={event?.venue || ""}
              {...register("venue",{required:true})}
              error={errors.venue && "venue is required"}
              />

            <Form.Field>
              <Controller
                name="date"
                control={control}
                rules={{required:"Data is required"}}
                defaultValue={event && new Date(event.date) || null}
                render={({field})=>
                (
                  <DatePicker 
                    selected={field.value}
                    onChange={value=>setValue("date",value,{shouldValidate:true})}
                    showTimeSelect
                    timeCaption="time"
                    dateFormat="MMM d,yyyy h:mm aa"
                    placeholderText="Event date and Time"
                  />
                )

              }
              />
            </Form.Field>

            
            <Button loading={isSubmitting} disabled={!isValid} type="submit" floated="right" positive content="Submit" />
            <Button loading={isSubmitting} type="button" as={Link} to="/events" floated="right" content="Cancel" />
        </Form>
    </Segment>  
  </>
  )
}