import { createSlice } from "@reduxjs/toolkit";
import { AppEvent } from "../../types/eventypes";
import { sampleData } from "../../api/sampleData";


type State =
{
    events:AppEvent[]
}

const initialState : State=
{
    events:sampleData
}

export const eventSlice = createSlice(
    {
        name:"event",
        initialState,
        reducers:
        {
            createEvent:(state,action)=>
            {
                //console.log(action.payload)
                action.payload.state.id=action.payload.id
                state.events.push(action.payload.state)
            },
           updateEvent:(state,action)=>
           {
                state.events[state.events.findIndex(el=>el.id==action.payload.state.id)]=action.payload.state
           },
           deleteEvent:(state,action)=>
           {
                const index= state.events.findIndex(el=>el.id===action.payload)
                state.events.splice(index,1);
           },
        },
    }
)

export const {createEvent,updateEvent,deleteEvent} = eventSlice.actions;