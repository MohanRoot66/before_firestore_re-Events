import { Grid } from "semantic-ui-react";
import EventDetailHeader from "./EventDetailHeader";
import EventDetailInfo from "./EventDetailInfo";
import EventDetailChat from "./EventDetailChat";
import EventDetailSidebar from "./EventDetailSidebar";
import { useParams } from "react-router-dom";
import { useAppSelector } from "../../../Store/store";

export default function EventDetailedPage() {
  
  const {id} = useParams()

  const event = useAppSelector(state=>state.events).events.find(el=>el.id===id);

  if(!event)
    return <p>Not Found an Event</p>

  return (
    <Grid>
      <Grid.Column width={10}>
        <EventDetailHeader event={event}/>
        <EventDetailInfo event={event}/>
        <EventDetailChat/>
      </Grid.Column>
      <Grid.Column width={6}>
        <EventDetailSidebar/>
      </Grid.Column>
    </Grid>
  )
}
