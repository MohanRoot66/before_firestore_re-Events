import { Link, useNavigate } from "react-router-dom"
import { Menu,Image, Dropdown } from "semantic-ui-react"
import { useAppDispatch, useAppSelector } from "../../Store/store";
import { signOut } from "../../features/auth/authSlice";



export default function SignedinMenu() {
    const navigate = useNavigate();
    const {currentUser} = useAppSelector(state=>state.auth)
    const dispatch = useAppDispatch();
    function handleSignout()
    {
        dispatch(signOut());
        navigate("/")
    }

  return (
    <Menu.Item position="right">
        <Image avatar spaced='right' src="/logo.png"/>
        <Dropdown pointing="top left" text={currentUser?.email}>
            <Dropdown.Menu>
                <Dropdown.Item as={Link} to="/createEvent" text="Create event" icon="plus"/>
                <Dropdown.Item text="My Profile" icon="user"/>
                <Dropdown.Item onClick={()=>handleSignout()} as={Link} to="/" text="Sign Out" icon="power"/>
            </Dropdown.Menu>
        </Dropdown>
    </Menu.Item>
  )
}