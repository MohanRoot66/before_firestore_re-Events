import { MenuItem,Button } from "semantic-ui-react";
import { useAppDispatch } from "../../Store/store";
import { openModel } from "../../common/models/modelSlice";


export default function SignedoutButton() {
  const dispatch = useAppDispatch()
  return (
  <>
    <MenuItem position="right">
    <Button  basic inverted content="Login"
     onClick={()=>dispatch(openModel({type:"LoginForm"}))}  />
    <Button basic inverted content="Register" style={{ marginLeft: "0.5em" }} />
    </MenuItem>
    </>
  )
}
