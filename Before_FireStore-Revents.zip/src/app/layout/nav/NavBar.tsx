
import { NavLink } from "react-router-dom";
import { Button, Container, Menu, MenuItem } from "semantic-ui-react";
// import SignedoutButton from "./SignedoutButton";
import SignedinMenu from "./SignedinMenu";

import SignedoutButton from "./SignedoutButton";
import { useAppSelector } from "../../Store/store";



export default function NavBar() {

  const {authenticated} = useAppSelector(state=>state.auth)

  return (
    <Menu inverted={true} fixed="top">
      <Container>
        <MenuItem header as={NavLink} to="/">
          <img src="/logo.png" alt="" />
          Re-vents
        </MenuItem>
        <MenuItem name="Events" as={NavLink} to="/events" />
        <MenuItem name="Scrach" as={NavLink} to="/scrach" />
        <MenuItem as={NavLink} to="/createEvent">
          <Button
            floated="right"
            positive={true}
            inverted={true}
             // Pass a function reference
            content="Create event"
          />
        </MenuItem>
        {authenticated ? <SignedinMenu/> : <SignedoutButton/>}
      </Container>
    </Menu>
  );
}
