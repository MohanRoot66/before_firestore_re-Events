
import "./styles.css"
import NavBar from "./nav/NavBar"
import { Container } from "semantic-ui-react"
import { Outlet, useLocation } from "react-router-dom"
import Homepage from "../features/events/home/Homepage";
import Modelmanager from "../common/models/Modelmanager";


function App() {

  const location = useLocation();

  return (
    <>
      {location.pathname==="/" ? <Homepage/>:
          <>
          <Modelmanager/>
            <NavBar/>
            <Container className="main">
              <Outlet/>
            </Container>
            </>
    }
    </>
  )
}

export default App
