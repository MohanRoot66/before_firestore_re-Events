export type User = 
{
    email:string
    photoUrl : string
}