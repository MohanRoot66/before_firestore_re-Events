import { ReactNode } from "react"
import { Modal, ModalProps } from "semantic-ui-react"
import { useAppDispatch, useAppSelector } from "../../Store/store"
import { closeModel } from "./modelSlice"

type Props=
{
    children : ReactNode
    header: string
} & ModalProps

export default function ModelWrapper({children,header,...props}:Props) {
    const {open} = useAppSelector(state=>state.modals)
    const dispatch = useAppDispatch();
  return (
    <Modal open={open} onClose={()=>dispatch(closeModel())} size={props.size}>
        {header && <Modal.Header>{header}</Modal.Header>}
        <Modal.Content>
            {children}
        </Modal.Content>
    </Modal>
  )
}