import { createSlice } from "@reduxjs/toolkit"

type State=
{
    open:boolean
    type:string | null
    data:any
}

const initialState : State =
{
    open:false,
    type:null,
    data:null
}

export const modelSlice = createSlice(
    {
        name:"model",
        initialState,
        reducers:
        {
            openModel:(state,action)=>
            {
                state.type=action.payload.type;
                state.open=true
                state.data=action.payload.data
            },
            closeModel:(state)=>
            {
                state.open=false,
                state.type=null,
                state.data=null
            }
        }
    }
)

export const {openModel,closeModel} = modelSlice.actions