import { useAppSelector } from "../../Store/store"
import TestModel from "../../features/events/scrach/TestModel"
import LoginForm from "../../features/auth/LoginForm"
export default function Modelmanager() {

    const modelLookup = 
    {
        TestModel,
        LoginForm
    }

    const {type,data,open} = useAppSelector(state=>state.modals)

    let renderModal;

    if(open &&  type)
    {
        const ModelComponent = (modelLookup as any)[type];
        renderModal=<ModelComponent data={data}/>
    }

    return (
        <span>{renderModal}</span>
    )
}